import React, { useState, useEffect } from 'react';
import './navbar.css';

const Navbar = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const toggleMenu = () => {
        setIsMenuOpen(!isMenuOpen);
    };

    const closeMenu = () => {
        setIsMenuOpen(false);
    };

    // Close menu when clicking outside or on escape key
    useEffect(() => {
        const handleEscape = (e) => {
            if (e.key === 'Escape') {
                closeMenu();
            }
        };

        const handleClickOutside = (e) => {
            if (isMenuOpen && !e.target.closest('.header')) {
                closeMenu();
            }
        };

        if (isMenuOpen) {
            document.addEventListener('keydown', handleEscape);
            document.addEventListener('click', handleClickOutside);
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = 'unset';
        }

        return () => {
            document.removeEventListener('keydown', handleEscape);
            document.removeEventListener('click', handleClickOutside);
            document.body.style.overflow = 'unset';
        };
    }, [isMenuOpen]);

    return (
        <>
            <header className="header">
                <a href="#" className="logo">VERTECHX</a>
                <button
                    className={`bx ${isMenuOpen ? 'bx-x' : 'bx-menu'}`}
                    id="menu-icon"
                    onClick={toggleMenu}
                    aria-label={isMenuOpen ? 'Close menu' : 'Open menu'}
                ></button>
                <nav className={`navbar ${isMenuOpen ? 'active' : ''}`}>
                    <a href="#" onClick={closeMenu}>Home</a>
                    <a href="#" onClick={closeMenu}>Events</a>
                    <a href="#" onClick={closeMenu}>My Registration</a>
                    <a href="#" onClick={closeMenu}>Contact</a>
                    <a href="#" onClick={closeMenu}>Login to Register</a>
                </nav>
            </header>
            <div
                className={`nav-bg ${isMenuOpen ? 'active' : ''}`}
                onClick={closeMenu}
            ></div>
        </>
    );
};

export default Navbar;
